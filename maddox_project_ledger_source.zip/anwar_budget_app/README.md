# Maddox Project Ledger — Anwar Residence

A local-first budget and cash-control app for Android. The UI is a self-contained offline HTML app, bundled in an Android WebView wrapper. It does not call a server, use a cloud database, or require an account.

## Included features
- Central cash ledger with source/destination notes
- Cash inflows from Anwar Residence, other projects, or Maddox
- Expenses assigned to a project, with BOQ/expense category and Paid / Partially paid / Still owed status
- BOQ summary for seven Anwar Residence categories, matching the attached estimate
- Contract value and true profit-margin target (profit is a percentage of contract value)
- Category target spending based on the target margin
- Payment milestones with due amount, received amount, and earned-to-date amount
- Cash balance kept separate from incurred costs and earned revenue
- Local JSON backup and restore
- Transaction/audit history and category reports

## Important accounting behavior
- The cash balance changes for cash receipts and the paid portion of expenses.
- Unpaid/partially unpaid costs count as project costs for profitability but do not reduce cash until paid.
- Internal transfers are logged for traceability but do not change the single combined cash balance and are not revenue.
- Actual profit to date is calculated as revenue marked earned in milestones minus project costs recorded. Keep the earned amount updated based on work actually earned/completed; do not assume that money received is automatically revenue earned.
- “Profit at current cost” is a projection (contract value less recorded project costs), not final profit until all costs and scope changes are captured.
- BOQ category amounts are the estimates extracted from the user's BOQ; the contract value is editable because a BOQ estimate may differ from the signed contract.

## Run the web app for a quick preview
Open `www/index.html` in a modern browser. Browser file-origin storage varies by browser; use a normal local web origin if localStorage is blocked. In the Android wrapper, data is stored in WebView local storage on the device.

## Build the APK in Android Studio
1. Open the `android/` folder in Android Studio.
2. Install Android SDK Platform 35 and a compatible Android Gradle Plugin / Gradle version when prompted.
3. Let Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will create a debug APK under `android/app/build/outputs/apk/debug/`.
6. For personal installation, transfer that APK to the phone and allow installation from that source. For release distribution, create a signed release APK and keep the signing key safe.

Package ID: `com.maddox.anwarbudget`  
Version: `1.0.0`

## Data safety
Export a JSON backup regularly. Uninstalling the app or clearing its storage can erase the local database. This initial version stores data on the device and does not sync across phones.

## Build without a Windows computer (GitHub Actions)
The source ZIP includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`. To use it, create a GitHub repository and upload the *contents* of the `anwar_budget_app` folder to the repository root (so `android/`, `www/`, and `.github/` are at the top level), then open the repository's **Actions** tab and run **Build Android APK** (or push to `main`). When the run finishes, open it and download the artifact named `maddox-project-ledger-debug-apk`. Extract the artifact ZIP to obtain `app-debug.apk`. This requires a GitHub account and internet access; the build runs on GitHub's servers. The app itself remains local-only and does not send project data to GitHub.
